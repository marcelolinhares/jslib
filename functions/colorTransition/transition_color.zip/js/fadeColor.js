/************************************************************

	Fun??o para atribuir efeito de transi??o entre as cores
	dat

************************************************************/

var ____GLOBAL___TIMES___ = []
var velocity
var CONT_EVENT_FADE = 0

/**
 *	
 *  Efetuar transi??o de cores do background de um objeto
 *
 *	 @author: Marcelo Linhares
 *   @param: Object: __idObjectFade__ - Id do objeto que ir? sofrer altera??o de cor
 *	 @param: String: starColor - Cor inicial do objeto (em RGB, exemplo: 255|255|255
 *	 @param: String: endColor - Cor final do objeto (em RGB, exemplo: 0|0|0
 *	 @param: Integer: velocity - velocidade em que acontecer? a transforma??o
 *
 *	 @date: 03/05/2006 
 *	 @return: void
 */


function fadeColor(__idObjectFade__,startColor,endColor,velocity){
	//var velocity = _velocity
	//alert(velocity)	
	idObjectFade = __idObjectFade__
	startColor = startColor.split("|")
	endColor = endColor.split("|")
	this.color
	
	/* ---- Recebendo o RGB da cor inicial ---- */
	 startColorRed   = startColor[0]
	 startColorGreen = startColor[1]
	 startColorBlue  = startColor[2]

	/* ---- Recebendo o RGB da cor final ---- */
	 endColorRed   = endColor[0]
	 endColorGreen = endColor[1]
	 endColorBlue  = endColor[2]

	if(CONT_EVENT_FADE==1000){
		alert(CONT_EVENT_FADE)
		return 0
	}
	/* ---- Condi??o de parada da recurs?o, somente se a cor inicial for igual a final ---- */
	if(startColorRed == endColorRed && startColorGreen == endColorGreen && startColorBlue == endColorBlue){
	//	alert(this.color)
		return 0
	}
	else {


		/************************************

				Consist?ncia de cores

		************************************/
		
		/* --- Cor vermelha ---- */
		if(eval(startColorRed) > eval(endColorRed)){
			startColorRed--
		}
		else if(eval(startColorRed) < eval(endColorRed)) {
			startColorRed++
		}
		/* ---- Cor verde ----- */
		if(eval(startColorGreen) > eval(endColorGreen)){
			startColorGreen--
		}
		else if(eval(startColorGreen) < eval(endColorGreen)) {
			startColorGreen++
		}
	
		/* ----- Cor azul ----- */
		if(eval(startColorBlue) > eval(endColorBlue)){
			startColorBlue--
		}
		else if(eval(startColorBlue) < eval(endColorBlue)) {
			startColorBlue++
		}
	
		this.color = "rgb("+startColorRed+","+startColorGreen+","+startColorBlue+")"
		idObjectFade.style.backgroundColor = this.color 
		
		/* Criando as cores */
		stringStartColor =  startColorRed + "|" + startColorGreen + "|" + startColorBlue
		stringEndColor = endColorRed + "|" + endColorGreen + "|" + endColorBlue 
		
		/* chamando a recurs?o */ 
		____GLOBAL___TIMES___[CONT_EVENT_FADE++] = setTimeout("fadeColor(idObjectFade,stringStartColor,stringEndColor,velocity)",velocity)
		
		
	} // fim do else
}
