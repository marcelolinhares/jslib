package functions.ajaxPopulationSelect; public class categoriasVW extends com.just.work.web.WEBView  {public void execute() { contentType ="text/xml";write("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");
write("<select>\n");
write("\n");


 int  estado = Integer.parseInt ( request.getParameter ("categoria"));

 if ( estado ==1){;write("\n");
write("	<option>\n");
write("		<value>1</value>\n");
write("		<text>Rambo I</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>2</value>\n");
write("		<text>Rambo II</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>3</value>\n");
write("		<text>Rambo III</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>4</value>\n");
write("		<text>De Volta Para O Futuro</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>5</value>\n");
write("		<text>Deby e L�ide</text>	\n");
write("	</option>\n");
} else {;write("\n");
write("<option>\n");
write("		<value>8</value>\n");
write("		<text>A Vida � Bela</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>9</value>\n");
write("		<text>Amor meu Grande Amor</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>10</value>\n");
write("		<text>10 Formas de AMAR</text>	\n");
write("	</option>\n");
write("	<option>\n");
write("		<value>11</value>\n");
write("		<text>Meu Querido Presidente</text>	\n");
write("	</option>\n");
};write("\n");
write("\n");
write("</select>");}}