/************************************************************

	Fun??o para atribuir efeito de transi??o entre as cores
	dat

************************************************************/
function fadeColorMaster(){

	var ____GLOBAL___TIMES___
	var velocity
	var endColorRed
	var endColorGreen
	var endColorBlue 
	var startColorRed  
	var startColorGreen 
	var startColorBlue 
	var endColor = []
	var startColor = []
	
	/**
	 *	
	 *  Efetuar transi??o de cores do background de um objeto
	 *
	 *	 @author: Marcelo Linhares
	 *   @param: Object: __idObjectFade__ - Id do objeto que ir? sofrer altera??o de cor
	 *	 @param: String: starColor - Cor inicial do objeto (em RGB, exemplo: 255|255|255
	 *	 @param: String: endColor - Cor final do objeto (em RGB, exemplo: 0|0|0
	 *	 @param: Integer: velocity - velocidade em que acontecer? a transforma??o
	 *
	 *	 @date: 03/05/2006
	 *	 @return: void
	 */
	
	this.fadeColor = fadeColor
	
	function fadeColor(__idObjectFade__,startColor,endColor,velocity){
	
		idObjectFade = __idObjectFade__
		startColor = startColor.split("|")
		endColor = endColor.split("|")
	
		/* ---- Recebendo o RGB da cor inicial ---- */
		var startColorRed   = startColor[0]
		var startColorGreen = startColor[1]
		var startColorBlue  = startColor[2]
	
		/* ---- Recebendo o RGB da cor final ---- */
		var endColorRed   = endColor[0]
		var endColorGreen = endColor[1]
		var endColorBlue  = endColor[2]
	
		
		/* ---- Condi??o de parada da recurs?o, somente se a cor inicial for igual a final ---- */
		if(startColorRed == endColorRed && startColorGreen == endColorGreen && startColorBlue == endColorBlue){
			return 0
		}
		else {
	
	
			/************************************
	
					Consist?ncia de cores
	
			************************************/
			
			/* --- Cor vermelha ---- */
			if(eval(startColorRed) > eval(endColorRed)){
				startColorRed--
			}
			else if(eval(startColorRed) < eval(endColorRed)) {
				startColorRed++
			}
			/* ---- Cor verde ----- */
			if(eval(startColorGreen) > eval(endColorGreen)){
				startColorGreen--
			}
			else if(eval(startColorGreen) < eval(endColorGreen)) {
				startColorGreen++
			}
		
			/* ----- Cor azul ----- */
			if(eval(startColorBlue) > eval(endColorBlue)){
				startColorBlue--
			}
			else if(eval(startColorBlue) < eval(endColorBlue)) {
				startColorBlue++
			}
		
			_color = "rgb("+startColorRed+","+startColorGreen+","+startColorBlue+")"
			idObjectFade.style.backgroundColor = _color 
			
			/* Criando as cores */
			stringStartColor =  startColorRed + "|" + startColorGreen + "|" + startColorBlue
			stringEndColor = endColorRed + "|" + endColorGreen + "|" + endColorBlue 
			
			/* chamando a recurs?o */
			____GLOBAL___TIMES___ = setTimeout("this.fadeColor(idObjectFade,stringStartColor,stringEndColor,this.velocity)",this.velocity)
			
			
		} // fim do else
	} // fim da fun??o fadeColor
} // fim da fun??o fadeColorMaster